(function(){
"use strict";
function $(id){return document.getElementById(id);}
function css(n){return getComputedStyle(document.documentElement).getPropertyValue(n).trim();}

var stage=$("stage"),canvas=$("gl"),renderer;
try{
  if(!window.THREE)throw new Error("no three");
  renderer=new THREE.WebGLRenderer({canvas:canvas,antialias:true});
}catch(e){$("fail").style.display="flex";return;}
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));

/* ---------- world constants (metres) ---------- */
var V=function(x,y,z){return new THREE.Vector3(x,y,z);};
var YS=0;                  /* plant floor */
var A=YS+2.25,B=YS+1.35,R0=YS+0.75;
var F1Y=3.6,T=F1Y+2.25,TZ=33;   /* first floor level, Zone 1 trunk height and z */
var CX={1:-9.5,2:-15.0,3:-17.8}; /* FIS station x */
var TBN={1:"TUO-3",3:"ZF"};   /* names of the two end stations; the middle FIS-2 station is removed */
var TBLY=0.95;                      /* inspection table belt height */
var LANE={A:11.0,B:17.8};
var RJZ=8.4,SCX=5.6;            /* rejected conveyor x, barcode trigger x */
var DZ=-18;                      /* Zone 2 and Zone 3 shifted forward by 18 m in total so they sit clear of the first floor */
var BZ=13.0+DZ,DROPX=5.4,DBM2Z=15.8+DZ,DBM1Z=20.9+DZ,TRTX=-7.3,OUTZ=10.7+DZ,RJX=-3.5,ZL=19.8+DZ;   /* ZL: where the feed lanes start */
var FX=TRTX-0.6,FZ=24+DZ;                 /* FIS section origin: moved north to the top end of the TRT belt, just before the DBM-1 line */
var FLOORS=[
  {k:"G",name:"Ground floor",role:"Zone 2: lanes, DBM, TRT, FIS, inspection",y:0,col:"--fs",w:56,d:51.5,cx:-3,cz:12.2,lz:35.6},
  {k:"F",name:"First floor",role:"Zone 1: TU01 to TU08, barcode trigger, trunk",y:F1Y,col:"--fz",w:50,d:23,cx:0,cz:32.5,lz:34.2}
];
function fkeyAtY(y){return y>=3.3?"F":"G";}

/* ---------- conveyor definitions (flow runs first point to last) ---------- */
/* west U-bend: closes the loop between the end of the rejected run and the start of the Zone 1 trunk */
var BENDX=-22,BENDR=(36.6-33)/2,BENDZ=(36.6+33)/2;
function uBend(n){var o=[];for(var k=1;k<=n;k++){var a=Math.PI*k/n;o.push(V(BENDX-BENDR*Math.sin(a),T,BENDZ+BENDR*Math.cos(a)));}return o;}
/* merger conveyor: angled S-curve that feeds into the rejected run */
var MG={x0:-3.5,x1:-13.5,zA:39.2,zB:36.6};
function mergerPts(n){var o=[];for(var k=0;k<=n;k++){var u=k/n;o.push(V(MG.x0+(MG.x1-MG.x0)*u,T,MG.zA-(MG.zA-MG.zB)*(.5-.5*Math.cos(Math.PI*u))));}return o;}
var C={},ORDER=[];
var Z3={s:0.0225,y:A,xc:DROPX,zn:6.25};   /* Zone 3 rollers sit at the FIS belt level; the 575BF3 block at the drop stays at 1.35 m and the green belt rises between them */   /* sized and placed from the notebook sketch: green belt at the drop end, long roller about 4.8 m south of it */
var REMOVED={br08:1,laneA:1,laneB:1,band:1,inland:1,outlet:1};   /* belts taken out of the 3D view: feed lanes A and B, Zone-2 line, Inland belt, TRT outlet */
function conv(id,o){o.id=id;o.passed=0;o.now=0;o.hidden=!!o.hidden;C[id]=o;ORDER.push(id);return o;}
var TUOX={1:-14.8,2:-8.25,3:0.76,4:-20.0,5:-3.7};
var TUO=[
  {n:4,lab:"TU01",x:TUOX[4],h:1.10,ref:"26 / 06A / 26D",sp:"11.5 m/min at the foot, 35 m/min at the machine",bin:"BAD tyres"},
  {n:1,lab:"TU03",x:TUOX[1],h:1.25,ref:"26A / 26E / 06B",sp:"",bin:"BAD tyres"},
  {n:2,lab:"TU04",x:TUOX[2],h:1.36,ref:"06 / 26B / 26F / 06C",sp:"",bin:"BAD tyres"},
  {n:3,lab:"TU08",x:TUOX[3],h:1.10,ref:"26C / 26G / 06D",sp:"25 m/min",bin:"LVD tyres"},
  {n:5,lab:"TU07",x:TUOX[5],h:1.25,ref:"26H / 06E",sp:"",bin:"BAD tyres"}
];
TUO.forEach(function(t){
  conv("tuo"+t.n,{name:t.lab+" feeder",ref:t.ref,h:t.h.toFixed(3)+" m at the machine, rising to 2.250 m",grp:"F",w:1.3,
    flow:t.lab+" machine down to the Zone 1 trunk"+(t.sp?" ("+t.sp+")":""),
    pts:[V(t.x,F1Y+t.h,25.4),V(t.x,F1Y+t.h,29.0),V(t.x,T,32.2),V(t.x,T,TZ)]});
});
conv("z1trunk",{name:"Zone 1 trunk and belt 09",ref:"100 / 06 and 26 series, belt 09 after the bend",h:"2.250 m, belt 09 down to 0.75 m",grp:"F",w:1.3,
  flow:"West to east past the barcode trigger, collects TU01 to TU08, bends down as belt 09 into feed lane B",
  pts:[V(-22,T,TZ),V(LANE.B,T,TZ),V(LANE.B,T,31),V(LANE.B,R0,ZL)]});
conv("br08",{name:"Belt 08",ref:"08",h:"2.250 m on the first floor, down to 0.75 m",grp:"F",w:1.3,
  flow:"Branches off the trunk, first floor to ground floor, into feed lane A",pts:[V(LANE.A,T,TZ),V(LANE.A,T,31),V(LANE.A,R0,ZL)]});
conv("rejz",{name:"Rejected conveyor",ref:"drawing note: NO READABLE, WRONG CAGES",h:"2.250 m",grp:"F",w:1.3,
  flow:"Takes tyres the barcode trigger could not read along the return run, round the west U-bend and back to the start of the trunk; no-read tyres are lifted off at the no-read bin",pts:[V(RJZ,T,TZ),V(RJZ,T,36.6),V(BENDX,T,36.6)].concat(uBend(24))});
function eBend(n){var o=[];for(var k=0;k<=n;k++){var a=Math.PI*k/n;o.push(V(LANE.B+BENDR*Math.sin(a),T,TZ+BENDR*(1-Math.cos(a))));}return o;}
conv("rejeast",{name:"Rejected conveyor east extension",ref:"drawing note: NO READABLE, WRONG CAGES",h:"2.250 m",grp:"F",w:1.3,
  flow:"Return run extended east to the corner at the end of the trunk, closing the loop on that side",pts:eBend(24).concat([V(RJZ-1.6,T,36.6)])});
conv("rejstub",{name:"Rejected conveyor exit",ref:"drawing note: NO READABLE, WRONG CAGES",h:"2.250 m",grp:"F",w:1.3,
  flow:"Short belt leaving the rejected return run at right angles, ends at the no-read bin",pts:[V(-19.5,T,36.6),V(-19.5,T,38.6)]});
conv("merger",{name:"Merger conveyor",ref:"merger conveyor (as drawn in the reference)",h:"2.250 m",grp:"F",w:1.3,green:true,solid:true,
  flow:"Short green belt that feeds onto the rejected return run from the front",pts:[V(-11,T,42.0),V(-11,T,37.5)]});
conv("laneA",{name:"Feed lane A",ref:"08 (matched by role)",h:"0.75 m rising to 2.25 m",grp:"G",w:1.3,
  flow:"Arrives from belt 08, up to the Zone-2 line",pts:[V(LANE.A,R0,ZL),V(LANE.A,A,14.6+DZ),V(LANE.A,A,BZ)]});
conv("laneB",{name:"Feed lane B",ref:"09 (matched by role)",h:"0.75 m rising to 2.25 m",grp:"G",w:1.3,
  flow:"Arrives from belt 09, up to the Zone-2 line",pts:[V(LANE.B,R0,ZL),V(LANE.B,A,14.6+DZ),V(LANE.B,A,BZ)]});
conv("band",{name:"Zone-2 line",ref:"32N / 10A / 10 / 09B / 32F / 29 / 33A / 32A, BCR 2 and 3 (matched by role)",h:"2.250 m",grp:"G",w:1.3,
  flow:"East to west, ends at the Inland belt",pts:[V(21.5,A,BZ),V(0,A,BZ)]});
conv("drop",{name:"Drop to DBMs",ref:"not numbered on the drawing (matched by role)",h:"1.350 m, flat",grp:"G",w:1.3,
  flow:"North to south from the Zone-2 line, past S6 then S5",pts:[V(DROPX,B,BZ),V(DROPX,B,24.0+DZ)]});   /* far end extended by 2 m */
conv("z3link",{name:"Drop to Zone 3",ref:"link from the DBM drop end to the 575BF3 block of Zone 3 (sketch only)",h:"1.350 m",grp:"G",w:1.3,
  flow:"Continues the DBM drop from beside S5 to the 575BF3 roller block, where Zone 3 starts",pts:[V(DROPX,B,24.0+DZ),V(DROPX,B,Z3.zn+0.2)]});
var Z3R={zl:Z3.zn+0.2,zg:Z3.zn+(98.5-25)*Z3.s,zr:Z3.zn+(300-25)*Z3.s,xw:Z3.xc+(92.5-588)*Z3.s,xs:{}};
[[1,305],[2,770],[3,822]].forEach(function(d){Z3R.xs[d[0]]=Z3.xc+(d[1]-588)*Z3.s;});
conv("z3path",{nobuild:true,name:"Zone 3 rollers and green belt",ref:"Zone 3 picture",h:"1.350 m",grp:"G",w:1.3,
  flow:"From the 575BF3 block, along the green belt, down the entry roller past the barcode scanner, then along the long roller to FIS-1, FIS-2 and FIS-3",
  pts:[V(DROPX,B,Z3R.zl),V(DROPX,B,Z3R.zg),V(Z3R.xw,A,Z3R.zg),V(Z3R.xw,A,Z3R.zr),V(Z3R.xs[3],A,Z3R.zr)]});
conv("z3belt",{z3green:true,keepGreen:true,name:"Zone 3 green belt",ref:"green belt between the Zone 3 entry roller and the 575BF3 block (sketch only)",h:"1.350 m at the block, rising gently to 2.250 m",grp:"G",w:1.15,
  flow:"One continuous green conveyor from the 575BF3 roller block west to the Zone 3 west roller, rising gently so that it meets the FIS belt level without a drop",
  pts:[V(Z3.xc+(563-588)*Z3.s,B,Z3R.zg),V(Z3.xc+(118-588)*Z3.s,A,Z3R.zg)]});
/* link from the TRT belt end (where the FIS belt starts) round a square corner into the west roller of Zone 3, as in the notebook sketch */
var z3lp=(function(){
  var xe=Z3.xc+(92.5-588)*Z3.s,zN=Z3.zn+(73-25)*Z3.s+0.05;
  return [V(FX,A,FZ),V(xe,A,FZ),V(xe,A,zN)];   /* starts at the end of the FIS belt, square corner, as in the notebook sketch */
})();
conv("z3l",{z3green:true,sharp:true,name:"FIS to Zone 3 link",ref:"link from the end of the FIS belt to the Zone 3 west roller (notebook sketch)",h:"2.250 m",grp:"G",w:1.15,
  flow:"Starts at the end of the FIS belt, runs east, turns a square corner south and joins the west roller of Zone 3",
  pts:z3lp});
conv("dbm2",{name:"DBM-2 line",ref:"DBM, H.1350",h:"1.350 m",grp:"G",w:1.3,
  flow:"East to west through DBM-2, into the TRT belt",pts:[V(DROPX,B,DBM2Z),V(TRTX,B,DBM2Z)]});
conv("dbm1",{name:"DBM-1 line",ref:"DBM Recheck, H.1300",h:"1.350 m",grp:"G",w:1.3,
  flow:"East to west through DBM-1, into the TRT belt",pts:[V(DROPX,B,DBM1Z),V(TRTX,B,DBM1Z)]});
conv("trt",{name:"TRT belt",ref:"not numbered on the drawing",h:"1.350 m",grp:"G",w:1.3,
  flow:"South to north, collects DBM-1 and DBM-2",pts:[V(TRTX,B,FZ),V(TRTX,B,OUTZ)]});
conv("outlet",{name:"TRT outlet",ref:"not numbered on the drawing",h:"1.350 m rising to 2.250 m",grp:"G",w:1.3,
  flow:"West to east, joins the Inland belt",pts:[V(TRTX,B,OUTZ),V(-1.5,A,OUTZ),V(0,A,OUTZ)]});
conv("inland",{name:"Inland belt",ref:"mezzanine conveyor, H.2360 to H.750 (matched by role)",h:"2.250 m",grp:"G",w:1.3,
  flow:"South to north, carries bypass and TRT tyres",pts:[V(0,A,BZ),V(0,A,DZ)]});
conv("fis",{name:"FIS belt",ref:"mezzanine conveyor, H.2360 (matched by role)",h:"2.250 m",grp:"G",w:1.3,
  flow:"East to west past FIS-1 and FIS-3",pts:[V(FX,A,FZ),V(FX-19.8,A,FZ)]});
conv("fislink",{nobuild:true,name:"FIS feed",ref:"link from the Inland belt to the FIS belt",h:"2.250 m",grp:"G",w:1.3,
  flow:"Carries tyres from the end of the Inland belt to the start of the FIS belt",pts:[V(0,A,DZ),V(FX,A,DZ),V(FX,A,FZ)]});
[1,3].forEach(function(f){
  conv("inc"+f,{name:"FIS-"+f+" inclined conveyor",ref:"FIS-"+f+" (sketch only)",h:"2.250 m down to 0.95 m",grp:"G",w:1.3,
    flow:"Leaves the FIS belt on the same floor, down to "+TBN[f],pts:[V(FX+CX[f],A,FZ),V(FX+CX[f],A,FZ-1.6),V(FX+CX[f],TBLY,FZ-9.0)]});
  conv("tab"+f,{name:TBN[f],ref:TBN[f]+" (sketch only)",h:"0.95 m",grp:"G",w:1.3,
    flow:"Tyre waits here for inspection",pts:[V(FX+CX[f],TBLY,FZ-9.0),V(FX+CX[f],TBLY,FZ-10.6)]});
});

ORDER.forEach(function(id){C[id].vpts=C[id].grp==="F"?roundPts(C[id].pts,1.6,function(a,p,b){return !(C[id].id==="merger"||C[id].id==="rejeast"||(C[id].id==="rejz"&&p.x<=BENDX+.01));}):C[id].pts;});

/* photo-eyes: s = sensor, r = reflector opposite, ax = axis the belt runs along */
var SENS=[
  {id:"S3",name:"Lane A start",c:"laneA",x:LANE.A,z:18.4+DZ,ax:"z",refl:"R3"},
  {id:"S1",name:"Lane A merge",c:"laneA",x:LANE.A,z:14.0+DZ,ax:"z"},
  {id:"HOLD",name:"Lane B hold",c:"laneB",x:LANE.B,z:18.4+DZ,ax:"z",refl:"R"},
  {id:"S2",name:"Lane B merge",c:"laneB",x:LANE.B,z:14.0+DZ,ax:"z"},
  {id:"S6",name:"DBM-2 entry",c:"drop",x:DROPX,z:DBM2Z,ax:"z"},
  {id:"S5",name:"DBM-1 entry",c:"drop",x:DROPX,z:DBM1Z,ax:"z"},
  {id:"TS1",name:"TRT outlet",c:"outlet",x:-5.4,z:OUTZ,ax:"x"},
  {id:"TS2",name:"TRT centre",c:"outlet",x:-2.2,z:OUTZ,ax:"x"},
  {id:"IS",name:"Inland start",c:"inland",x:0,z:11.8+DZ,ax:"z"},
  {id:"FIS-1",name:"FIS-1 station",c:"fis",x:FX+CX[1]+1.2,z:FZ,ax:"x"},
  {id:"FIS-3",name:"FIS-3 station",c:"fis",x:FX+CX[3]+1.2,z:FZ,ax:"x"},
  {id:"BC",name:"Barcode trigger",c:"z1trunk",x:SCX,z:TZ,ax:"x"}
];
var REFL=[
  {id:"R1",c:"band",x:LANE.A+1.6,z:BZ,ax:"x"},
  {id:"R2",c:"band",x:LANE.B+1.6,z:BZ,ax:"x"}
];
SENS=SENS.filter(function(s){return !REMOVED[s.c];});
REFL=REFL.filter(function(s){return !REMOVED[s.c];});
var EQ=[
  {l:"DBM-2",f:"G",x:-1.2,y:B,z:DBM2Z,w:3.6,h:2.4,d:2.6,dy:-0.2},
  {l:"DBM-1",f:"G",x:-1.2,y:B,z:DBM1Z,w:3.6,h:2.4,d:2.6,dy:-0.2},
];
TUO.forEach(function(t){
  EQ.push({l:"",f:"F",x:t.x,y:F1Y,z:23.6,w:3.2,h:2.2,d:2.4});
  EQ.push({l:"",f:"F",x:t.x-2.2,y:F1Y,z:30.6,w:1.2,h:0.9,d:1.2});
  EQ.push({l:t.bin,f:"F",x:t.x+2.2,y:F1Y,z:30.6,w:1.2,h:0.9,d:1.2});
});
EQ.push({l:"No-read bin",f:"F",x:-19.5,y:F1Y,z:39.5,w:1.6,h:1.0,d:1.2});
[1,3].forEach(function(f){EQ.push({l:TBN[f],f:"G",x:FX+CX[f],y:0,z:FZ-11.7,w:2.4,h:0.8,d:2.4});});

/* ---------- path helpers ---------- */
function roundPts(pts,r,ok){
  if(pts.length<3)return pts.slice();
  var out=[pts[0]];
  for(var i=1;i<pts.length-1;i++){
    var p=pts[i],a=pts[i-1],b=pts[i+1];
    if(ok&&!ok(a,p,b)){out.push(p);continue;}
    var d1=p.clone().sub(a),d2=b.clone().sub(p),l1=d1.length(),l2=d2.length();
    d1.normalize();d2.normalize();
    var ang=Math.acos(Math.max(-1,Math.min(1,d1.dot(d2))));
    if(ang<0.35){out.push(p);continue;}
    var t=Math.min(r*Math.tan(ang/2),0.45*l1,0.45*l2);
    var pin=p.clone().sub(d1.clone().multiplyScalar(t)),pout=p.clone().add(d2.clone().multiplyScalar(t));
    for(var k=0;k<=6;k++){
      var u=k/6,w1=(1-u)*(1-u),w2=2*u*(1-u),w3=u*u;
      out.push(new THREE.Vector3(pin.x*w1+p.x*w2+pout.x*w3,pin.y*w1+p.y*w2+pout.y*w3,pin.z*w1+p.z*w2+pout.z*w3));
    }
  }
  out.push(pts[pts.length-1]);
  return out;
}
function build(parts){
  var pts=[],marks=[];
  parts.forEach(function(p){
    var first=true,idx=0;
    p.pts.forEach(function(q){
      var l=pts[pts.length-1];
      if(l&&l.distanceToSquared(q)<1e-6){if(first){idx=pts.length-1;first=false;}return;}
      pts.push(q);
      if(first){idx=pts.length-1;first=false;}
    });
    marks.push({id:p.id,idx:idx});
  });
  var mp=marks.map(function(m){return pts[m.idx].clone();});
  var sp=roundPts(pts,1.6,function(a,p,b){return a.y>=3.3&&p.y>=3.3;});
  var cum=[0];
  for(var i=1;i<sp.length;i++)cum.push(cum[i-1]+sp[i].distanceTo(sp[i-1]));
  marks.forEach(function(m,mi){
    var best=0,bd=1e9;
    for(var j=0;j<sp.length;j++){var dd=sp[j].distanceToSquared(mp[mi]);if(dd<bd){bd=dd;best=j;}}
    m.d=cum[best];
  });
  return{pts:sp,cum:cum,marks:marks,total:cum[cum.length-1]};
}
function posAt(path,d){
  var pts=path.pts,cum=path.cum,i=0;
  while(i<pts.length-2&&cum[i+1]<d)i++;
  var a=pts[i],b=pts[i+1],L=cum[i+1]-cum[i],t=L?(d-cum[i])/L:1;
  t=Math.max(0,Math.min(1,t));
  var h=b.clone().sub(a).normalize();
  return{p:a.clone().lerp(b,t),h:h};
}
function pc(id,pts){return{id:id,pts:pts};}
function rev(parts){return parts.slice().reverse().map(function(q){return pc(q.id,q.pts.slice().reverse());});}   /* flow reversed */
function route(k,lane,via,dest,noRead){
  var sx=LANE[lane],lid="lane"+lane,tx=TUOX[k];
  var parts=[pc("tuo"+k,C["tuo"+k].pts.slice())];
  if(noRead){
    parts.push(pc("z1trunk",[V(tx,T,TZ),V(RJZ,T,TZ)]));
    parts.push(pc("rejz",[V(RJZ,T,TZ),V(RJZ,T,36.6),V(-19.5,T,36.6)]));
    parts.push(pc("rejstub",[V(-19.5,T,36.6),V(-19.5,T,38.6)]));
    return build(rev(parts));
  }
  if(lane==="A"){
    parts.push(pc("z1trunk",[V(tx,T,TZ),V(sx,T,TZ)]));
    parts.push(pc("br08",[V(sx,T,TZ),V(sx,T,31),V(sx,R0,ZL)]));
  }else{
    parts.push(pc("z1trunk",[V(tx,T,TZ),V(sx,T,TZ),V(sx,T,31),V(sx,R0,ZL)]));
  }
  parts.push(pc(lid,[V(sx,R0,ZL),V(sx,A,14.6+DZ),V(sx,A,BZ)]));
  var tail=function(fromZ){
    return [
      pc("inland",[V(0,A,fromZ),V(0,A,DZ)]),
      pc("fislink",[V(0,A,DZ),V(FX,A,DZ),V(FX,A,FZ)]),
      pc("fis",[V(FX,A,FZ),V(FX+CX[dest],A,FZ)]),
      pc("inc"+dest,[V(FX+CX[dest],A,FZ),V(FX+CX[dest],A,FZ-1.6),V(FX+CX[dest],TBLY,FZ-9.0)]),
      pc("tab"+dest,[V(FX+CX[dest],TBLY,FZ-9.0),V(FX+CX[dest],TBLY,FZ-10.6)])
    ];
  };
  if(via==="bypass"){
    parts.push(pc("band",[V(sx,A,BZ),V(0,A,BZ)]));
    parts=parts.concat(tail(BZ));
  }else{
    var n=via==="dbm1"?1:2,zb=n===1?DBM1Z:DBM2Z;
    parts.push(pc("band",[V(sx,A,BZ),V(DROPX,B,BZ)]));
    parts.push(pc("drop",[V(DROPX,B,BZ),V(DROPX,B,zb)]));
    parts.push(pc("dbm"+n,[V(DROPX,B,zb),V(TRTX,B,zb)]));
    parts.push(pc("trt",[V(TRTX,B,zb),V(TRTX,B,OUTZ)]));
    parts.push(pc("outlet",[V(TRTX,B,OUTZ),V(-1.5,A,OUTZ),V(0,A,OUTZ)]));
    parts=parts.concat(tail(OUTZ));
  }
  return build(rev(parts));
}
function routeZ3(via,dest,st){   /* as marked on the screenshot: up the incline, along the FIS belt past the barcode reader to the junction, then left through the FIS-to-Zone-3 link, down the west roller and along the long roller to the station */
  var cx=FX+CX[dest],xw=Z3R.xw,zN=z3lp[z3lp.length-1].z;
  var parts=[
    pc("tab"+dest,[V(cx,TBLY,FZ-10.6),V(cx,TBLY,FZ-9.0)]),
    pc("inc"+dest,[V(cx,TBLY,FZ-9.0),V(cx,A,FZ-1.6),V(cx,A,FZ)]),
    pc("fis",[V(cx,A,FZ),V(FX,A,FZ)]),
    pc("z3l",z3lp.map(function(q){return q.clone();})),
    pc("z3path",[V(xw,A,zN),V(xw,A,Z3R.zr),V(Z3R.xs[st],A,Z3R.zr)])
  ];
  return build(parts);
}
function nearestY(pts,x,z){
  var best=1e9,y=pts[0].y;
  for(var i=0;i<pts.length-1;i++){
    var a=pts[i],b=pts[i+1],dx=b.x-a.x,dz=b.z-a.z,L=dx*dx+dz*dz;
    var t=L?((x-a.x)*dx+(z-a.z)*dz)/L:0;t=Math.max(0,Math.min(1,t));
    var qx=a.x+dx*t,qz=a.z+dz*t,d=(qx-x)*(qx-x)+(qz-z)*(qz-z);
    if(d<best){best=d;y=a.y+(b.y-a.y)*t;}
  }
  return y;
}

/* ---------- scene, theme ---------- */
var scene=new THREE.Scene();
var camera=new THREE.PerspectiveCamera(38,1,0.5,500);
var controls=new THREE.OrbitControls(camera,canvas);
controls.enableDamping=true;controls.dampingFactor=.08;controls.maxPolarAngle=Math.PI*0.495;
scene.add(new THREE.HemisphereLight(0xffffff,0x8892a0,0.9));
var sun=new THREE.DirectionalLight(0xffffff,0.7);sun.position.set(30,60,40);scene.add(sun);

var themed=[];       /* functions re-run on theme change */
function onTheme(fn){themed.push(fn);fn();}
function applyTheme(){scene.background=new THREE.Color(css("--bg3d")||"#e6eaee");themed.forEach(function(f){f();});}

var GR={};
FLOORS.forEach(function(f){var g=new THREE.Group();GR[f.k]=g;scene.add(g);});
var on={G:true,F:true};

/* labels */
var labels=[],labelsOn=true;
function makeLabel(text,size,parent,pos,opts){
  opts=opts||{};size=size*1.05;
  var cv=document.createElement("canvas"),sp=new THREE.Sprite(new THREE.SpriteMaterial({transparent:true,depthTest:false}));
  var lab={cv:cv,sp:sp,text:text,size:size,col:opts.col||"--ink"};
  function draw(){
    var fs=opts.fs||36,ctx=cv.getContext("2d");
    ctx.font="600 "+fs+"px 'Barlow Semi Condensed','Arial Narrow',Arial,sans-serif";
    var w=Math.ceil(ctx.measureText(text).width)+20;
    cv.width=w;cv.height=fs+16;
    ctx=cv.getContext("2d");
    ctx.font="600 "+fs+"px 'Barlow Semi Condensed','Arial Narrow',Arial,sans-serif";
    ctx.textAlign="center";ctx.textBaseline="middle";
    ctx.lineWidth=7;ctx.lineJoin="round";ctx.strokeStyle=css("--bg3d")||"#e6eaee";
    ctx.strokeText(text,w/2,cv.height/2+1);
    ctx.fillStyle=(lab.col.charAt(0)==="#"?lab.col:css(lab.col))||"#1c2228";
    ctx.fillText(text,w/2,cv.height/2+1);
    if(sp.material.map)sp.material.map.dispose();
    sp.material.map=new THREE.CanvasTexture(cv);sp.material.needsUpdate=true;
    sp.scale.set(size*cv.width/cv.height,size,1);
  }
  lab.draw=draw;
  sp.position.copy(pos);sp.renderOrder=10;
  parent.add(sp);labels.push(lab);
  onTheme(draw);
  return lab;
}

function makeCard(text,o){
  o=o||{};
  var cv=document.createElement("canvas"),sp=new THREE.Sprite(new THREE.SpriteMaterial({transparent:true,depthTest:false}));
  var card={sp:sp};
  card.set=function(txt,bg,fg){
    var fs=o.fs||44,pad=o.pad||20,ctx=cv.getContext("2d"),font="600 "+fs+"px 'Barlow Semi Condensed','Arial Narrow',Arial,sans-serif";
    ctx.font=font;
    var w=Math.ceil(ctx.measureText(txt).width)+pad*2,h=Math.round(fs*1.5);
    cv.width=w;cv.height=h;ctx=cv.getContext("2d");ctx.font=font;
    var r=Math.min(16,h/2-2),x0=2,y0=2,x1=w-2,y1=h-2;
    ctx.beginPath();ctx.moveTo(x0+r,y0);ctx.arcTo(x1,y0,x1,y1,r);ctx.arcTo(x1,y1,x0,y1,r);ctx.arcTo(x0,y1,x0,y0,r);ctx.arcTo(x0,y0,x1,y0,r);ctx.closePath();
    ctx.fillStyle=bg;ctx.fill();
    ctx.strokeStyle=o.border||"rgba(0,0,0,.22)";ctx.lineWidth=2;ctx.stroke();
    ctx.fillStyle=fg;ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText(txt,w/2,h/2+1);
    if(sp.material.map)sp.material.map.dispose();
    sp.material.map=new THREE.CanvasTexture(cv);sp.material.needsUpdate=true;
    sp.scale.set((o.h||1)*w/h,(o.h||1),1);
  };
  sp.renderOrder=12;
  card.set(text,o.bg||"#ffffff",o.fg||"#1c2228");
  return card;
}

/* floors */
FLOORS.forEach(function(f,fi){
  var g=GR[f.k];
  var slabMat;
  if(f.k==="F"){
    var gcv=document.createElement("canvas");gcv.width=gcv.height=64;
    var gtex=new THREE.CanvasTexture(gcv);gtex.wrapS=gtex.wrapT=THREE.RepeatWrapping;gtex.repeat.set(f.w/1.5,f.d/1.5);
    slabMat=new THREE.MeshBasicMaterial({map:gtex,transparent:true,opacity:.92});
    onTheme(function(){
      var x=gcv.getContext("2d");x.fillStyle=css("--slabF");x.fillRect(0,0,64,64);
      x.strokeStyle=css("--gridF");x.lineWidth=3;x.strokeRect(0,0,64,64);gtex.needsUpdate=true;
    });
  }else slabMat=new THREE.MeshBasicMaterial({transparent:true,opacity:.16,depthWrite:false});
  var slab=new THREE.Mesh(new THREE.BoxGeometry(f.w,0.25,f.d),slabMat);
  slab.position.set(f.cx,f.y-0.13,f.cz);g.add(slab);
  var edges=new THREE.LineSegments(new THREE.EdgesGeometry(slab.geometry),new THREE.LineBasicMaterial());
  edges.position.copy(slab.position);g.add(edges);
  onTheme(function(){var c=css(f.col);if(f.k!=="F")slab.material.color.set(c);edges.material.color.set(c);});
  makeLabel(f.name.toUpperCase()+"  ·  "+f.role,1.0,g,V(-21.8,f.y+0.2,f.lz+1.5),{col:f.col,fs:34}).sp.center.set(0,.5);
});

/* belts */
var beltMat=new THREE.MeshStandardMaterial({roughness:.75,metalness:.1});
var railMat=new THREE.MeshStandardMaterial({roughness:.6,metalness:.2});
var tubeMat=new THREE.MeshBasicMaterial({transparent:true,opacity:.22,side:THREE.DoubleSide,depthWrite:false});
var eqMat=new THREE.MeshStandardMaterial({transparent:true,opacity:.55,roughness:.8});
var arrowBase=(function(){
  var c=document.createElement("canvas");c.width=128;c.height=64;
  var x=c.getContext("2d");x.strokeStyle="#fff";x.lineWidth=7;x.lineCap="round";x.lineJoin="round";
  x.beginPath();x.moveTo(44,14);x.lineTo(78,32);x.lineTo(44,50);x.stroke();
  var t=new THREE.CanvasTexture(c);t.wrapS=THREE.RepeatWrapping;return t;
})();
var arrowMat=new THREE.MeshBasicMaterial({map:arrowBase,transparent:true,opacity:.75,depthWrite:false});
onTheme(function(){
  beltMat.color.set(css("--belt3d"));railMat.color.set(css("--rail3d"));
  eqMat.color.set(css("--eq3d"));arrowMat.color.set(css("--arrow3d"));
});
var rollMat=new THREE.MeshStandardMaterial({roughness:.45,metalness:.5});
var frameBase=new THREE.MeshStandardMaterial({roughness:.55,metalness:.35});
var rollGeo=new THREE.CylinderGeometry(.075,.075,1,10);rollGeo.rotateX(Math.PI/2);
onTheme(function(){rollMat.color.set(css("--roller3d"));frameBase.color.set(css("--frame3d"));});
var pickables=[],texes=[],X=V(1,0,0);

function trimTrunk(pv){
  var o=[];
  for(var i=0;i<pv.length;i++){if(pv[i].z<TZ-0.001)break;o.push(pv[i]);}
  if(o.length&&o[o.length-1].x<LANE.B-0.001)o.push(V(LANE.B,T,TZ));
  return o;
}
/* green belt look from the Zone 3 picture: bright green, thin darker crossed cells, dark side rails */
function greenCellTex(cells){
  var cv=document.createElement("canvas"),cw=100,ch=68;cv.width=cw*cells;cv.height=ch;
  var cx=cv.getContext("2d");cx.fillStyle="#12d02a";cx.fillRect(0,0,cv.width,ch);cx.strokeStyle="#0a7d17";cx.lineWidth=3;
  for(var ci=0;ci<cells;ci++){cx.strokeRect(ci*cw+1.5,1.5,cw-3,ch-3);cx.beginPath();cx.moveTo(ci*cw,0);cx.lineTo((ci+1)*cw,ch);cx.moveTo((ci+1)*cw,0);cx.lineTo(ci*cw,ch);cx.stroke();}
  var t=new THREE.CanvasTexture(cv);t.anisotropy=8;return t;
}
function greenTopPlane(len,wid,cells){
  var m=new THREE.MeshBasicMaterial({map:greenCellTex(cells),polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
  var pl=new THREE.Mesh(new THREE.PlaneGeometry(len,wid),m);pl.rotation.x=-Math.PI/2;pl.position.y=.105;return pl;
}
function buildConv(c){
  if(c.nobuild)return;
  var g=new THREE.Group();g.userData.id=c.id;
  c.group=g;c.bodyMats=[];
  var grp=GR[c.grp];grp.add(g);
  if(REMOVED[c.id])return;
  if(c.tube){
    var p0=c.pts[0],p1=c.pts[1],h=p0.y-p1.y;
    var tube=new THREE.Mesh(new THREE.CylinderGeometry(c.w/2,c.w/2,h,20,1,true),tubeMat.clone());
    tube.position.set(p0.x,(p0.y+p1.y)/2,p0.z);tube.userData.id=c.id;
    onTheme(function(){tube.material.color.set(css("--accent"));});
    g.add(tube);c.bodyMats.push(tube.material);pickables.push(tube);
    var ring=new THREE.Mesh(new THREE.TorusGeometry(c.w/2,0.05,6,24),railMat);
    ring.rotation.x=Math.PI/2;ring.position.set(p0.x,p0.y,p0.z);g.add(ring);
    return;
  }
  if(c.keepGreen){   /* Zone 3 green belt: bright green, thin crossed cells, dark side rails */
    var kg=new THREE.MeshStandardMaterial({color:0x12d02a,roughness:.55,metalness:.1}),kd=new THREE.MeshStandardMaterial({color:0x2a3441,roughness:.6});
    c.bodyMats.push(kg);
    for(var ki=0;ki<c.pts.length-1;ki++){
      var ka=c.pts[ki],kb=c.pts[ki+1],kdir=kb.clone().sub(ka),kl=kdir.length();if(kl<1e-4)continue;kdir.normalize();
      var ks=new THREE.Group();ks.position.copy(ka).add(kb).multiplyScalar(.5);ks.quaternion.setFromUnitVectors(X,kdir);
      var km=new THREE.Mesh(new THREE.BoxGeometry(kl,0.18,c.w),kg);km.userData.id=c.id;ks.add(km);pickables.push(km);
      [-1,1].forEach(function(k){var kr=new THREE.Mesh(new THREE.BoxGeometry(kl,0.28,0.07),kd);kr.position.set(0,.1,k*c.w/2);ks.add(kr);});
      ks.add(greenTopPlane(kl,c.w-0.12,Math.max(1,Math.round(kl/(c.w*1.5)))));
      g.add(ks);
    }
    addLegs(c,g);
    return;
  }
  if(c.z3green){   /* Zone 3 links: same design as Zone 1 (side rails + rollers), square corner kept */
    var zf=frameBase.clone();c.bodyMats.push(zf);
    onTheme(function(){zf.color.set(css("--frame3d"));});
    var zHit=new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false});
    for(var zi=0;zi<c.pts.length-1;zi++){
      var za=c.pts[zi],zb2=c.pts[zi+1],zdir=zb2.clone().sub(za),zl=zdir.length();if(zl<1e-4)continue;zdir.normalize();
      var zs=new THREE.Group();zs.position.copy(za).add(zb2).multiplyScalar(.5);zs.quaternion.setFromUnitVectors(X,zdir);
      var eE=0,inS=0,inE=0,hw=c.w/2,lat=new THREE.Vector3(0,0,1).applyQuaternion(zs.quaternion);
      if(c.sharp){   /* square corners: the body runs on to cover the corner, outer rails wrap round it, inner rails stop at the inner corner */
        if(zi<c.pts.length-2){var nd=c.pts[zi+2].clone().sub(c.pts[zi+1]).normalize();eE=hw;inE=Math.sign(lat.dot(nd));}
        if(zi>0){var pd=c.pts[zi].clone().sub(c.pts[zi-1]).normalize();inS=Math.sign(lat.dot(pd.negate()));}
      }
      [-1,1].forEach(function(k){
        var xs=-zl/2,xe2=zl/2;
        if(inS){xs+=(k===inS)?hw:-hw;}
        if(inE){xe2+=(k===inE)?-hw:hw;}
        var rl2=new THREE.Mesh(new THREE.BoxGeometry(xe2-xs+0.01,0.26,0.07),zf);rl2.position.set((xs+xe2)/2,0,k*(hw+0.035));zs.add(rl2);
      });
      var r0=-zl/2+((c.sharp&&zi>0)?hw:0),r1=zl/2+eE,rlen=r1-r0;   /* rollers: skip the corner square on the next leg, it is covered by the previous one */
      var rn2=Math.max(1,Math.floor(rlen/0.3)),im2=new THREE.InstancedMesh(rollGeo,rollMat,rn2),mt2=new THREE.Matrix4(),qq2=new THREE.Quaternion();
      for(var rj2=0;rj2<rn2;rj2++){mt2.compose(new THREE.Vector3(r0+(rj2+.5)*rlen/rn2,0.03,0),qq2,new THREE.Vector3(1,1,c.w*0.95));im2.setMatrixAt(rj2,mt2);}
      zs.add(im2);
      var zhb=new THREE.Mesh(new THREE.BoxGeometry(zl+eE,0.4,c.w+0.2),zHit);zhb.position.x=eE/2;zhb.userData.id=c.id;zs.add(zhb);pickables.push(zhb);
      g.add(zs);
    }
    addLegs(c,g);
    return;
  }
  if(c.solid){
    var gMat=new THREE.MeshStandardMaterial({color:0x12d02a,roughness:.55,metalness:.1}),dMat=new THREE.MeshStandardMaterial({color:0x2a3441,roughness:.6});
    c.bodyMats.push(gMat);
    var sa=c.pts[0],sb=c.pts[1],sd=sb.clone().sub(sa),sl=sd.length();sd.normalize();
    var sg=new THREE.Group();sg.position.copy(sa).add(sb).multiplyScalar(.5);sg.quaternion.setFromUnitVectors(X,sd);
    var sm=new THREE.Mesh(new THREE.BoxGeometry(sl,0.18,c.w),gMat);sm.userData.id=c.id;sg.add(sm);pickables.push(sm);
    [-1,1].forEach(function(k){var r=new THREE.Mesh(new THREE.BoxGeometry(sl,0.28,0.07),dMat);r.position.set(0,.1,k*c.w/2);sg.add(r);});
    sg.add(greenTopPlane(sl,c.w-0.12,Math.max(1,Math.round(sl/(c.w*1.5)))));
    g.add(sg);
    [0.12,.88].forEach(function(u){
      var lp=sa.clone().lerp(sb,u),lh=lp.y-F1Y;
      var leg=new THREE.Mesh(new THREE.BoxGeometry(.12,lh,.12),dMat);leg.position.set(lp.x,F1Y+lh/2,lp.z);g.add(leg);
    });
    return;
  }
  if(c.grp==="F"||c.grp==="G"){   /* Zone 1 design (side rails + rollers) now also used for the Zone 2 belts */
    var frame=frameBase.clone();c.bodyMats.push(frame);
    onTheme(function(){frame.color.set(c.green?"#19a37a":css("--frame3d"));});
    var PV=c.id==="z1trunk"?trimTrunk(c.vpts):c.vpts,hitMat=new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false});
    for(var ri=0;ri<PV.length-1;ri++){
      var ra=PV[ri],rb=PV[ri+1],rd=rb.clone().sub(ra),rl=rd.length();
      if(rl<1e-4)continue;
      if(c.id==="br08")continue;   /* Belt 08 spur removed */
      if(c.id==="rejz"&&ra.x>RJZ-1.55&&ra.z<36.55)continue;   /* connector between trunk and return run removed */
      rd.normalize();
      var rs=new THREE.Group();
      rs.position.copy(ra).add(rb).multiplyScalar(.5);
      rs.quaternion.setFromUnitVectors(X,rd);
      [-1,1].forEach(function(k){
        var rail=new THREE.Mesh(new THREE.BoxGeometry(rl+0.02,0.26,0.07),frame);
        rail.position.set(0,0,k*(c.w/2+0.035));rs.add(rail);
      });
      var rn=Math.max(1,Math.floor(rl/0.3)),im=new THREE.InstancedMesh(rollGeo,rollMat,rn),mt=new THREE.Matrix4(),qq=new THREE.Quaternion();
      for(var rj=0;rj<rn;rj++){
        mt.compose(new THREE.Vector3((rj+.5)*rl/rn-rl/2,0.03,0),qq,new THREE.Vector3(1,1,c.w*0.95));
        im.setMatrixAt(rj,mt);
      }
      rs.add(im);
      var hb=new THREE.Mesh(new THREE.BoxGeometry(rl,0.4,c.w+0.2),hitMat);hb.userData.id=c.id;rs.add(hb);pickables.push(hb);
      g.add(rs);
    }
    addLegs(c,g);
    return;
  }
  var body=beltMat.clone();c.bodyMats.push(body);
  onTheme(function(){body.color.set(css("--belt3d"));});
  for(var i=0;i<c.pts.length-1;i++){
    var a=c.pts[i],b=c.pts[i+1],dir=b.clone().sub(a),len=dir.length();dir.normalize();
    var s=new THREE.Group();
    s.position.copy(a).add(b).multiplyScalar(.5);
    s.quaternion.setFromUnitVectors(X,dir);
    var m=new THREE.Mesh(new THREE.BoxGeometry(len,0.16,c.w),body);m.userData.id=c.id;s.add(m);pickables.push(m);
    var top=new THREE.Mesh(new THREE.PlaneGeometry(len,c.w*.8),arrowMat.clone());
    top.material.map=arrowBase.clone();top.material.map.needsUpdate=true;
    top.material.map.wrapS=THREE.RepeatWrapping;top.material.map.repeat.set(-len/1.6,1);
    top.rotation.x=-Math.PI/2;top.position.y=.09;s.add(top);texes.push(top.material.map);
    onTheme((function(mm){return function(){mm.color.set(css("--arrow3d"));};})(top.material));
    [-1,1].forEach(function(k){
      var r=new THREE.Mesh(new THREE.BoxGeometry(len,0.3,0.07),railMat);r.position.set(0,.1,k*c.w/2);s.add(r);
    });
    g.add(s);
    if(i>0){var j=new THREE.Mesh(new THREE.CylinderGeometry(c.w/2,c.w/2,.16,18),body);j.position.copy(a);g.add(j);}
  }
  addLegs(c,g);
}
function addLegs(c,g){
  var Lt=0;for(var k=0;k<c.pts.length-1;k++)Lt+=c.pts[k].distanceTo(c.pts[k+1]);
  var floorY=(c.grp==="F"&&c.id.indexOf("br")!==0)?F1Y:0;
  var n=Math.floor(Lt/4);
  for(var q=1;q<=n;q++){
    var pp=posAt({pts:c.pts,cum:cumOf(c.pts)},q*Lt/(n+1)).p;
    var h2=pp.y-floorY;if(h2<.5)continue;
    if(c.id==="rejz"&&pp.x>RJZ-1.55&&pp.z<36.55)continue;
    if((c.id==="br08"||c.id==="z1trunk")&&pp.z<TZ-0.01)continue;   /* legs of removed Belt 08 / Belt 09 */
    var leg=new THREE.Mesh(new THREE.BoxGeometry(.12,h2,.12),railMat);leg.position.set(pp.x,floorY+h2/2,pp.z);g.add(leg);
  }
}
function cumOf(pts){var c=[0];for(var i=1;i<pts.length;i++)c.push(c[i-1]+pts[i].distanceTo(pts[i-1]));return c;}
ORDER.forEach(function(id){buildConv(C[id]);});

/* equipment */
EQ.forEach(function(e){
  var m=new THREE.Mesh(new THREE.BoxGeometry(e.w,e.h,e.d),eqMat);
  m.position.set(e.x,e.y+e.h/2+(e.dy||0),e.z);GR[e.f].add(m);
  var ed=new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry),new THREE.LineBasicMaterial());
  ed.position.copy(m.position);GR[e.f].add(ed);
  onTheme(function(){ed.material.color.set(css("--muted"));});
  if(e.l)makeLabel(e.l,.9,GR[e.f],V(e.x,m.position.y+e.h/2+.7,e.z),{fs:32});
});
/* Zone 1: TUO stations, barcode trigger, rejected conveyor */
var tuoStat={},tuoBusy={},lastBC=null;
TUO.forEach(function(t){
  var card=makeCard(t.lab,{bg:"#f4c20d",fg:"#1c2228",fs:56,h:1.05,border:"rgba(0,0,0,.28)"});
  card.sp.position.set(t.x,F1Y+4.0,23.6);GR.F.add(card.sp);labels.push({sp:card.sp});
  var st=makeCard("READY",{bg:"rgba(0,0,0,0)",fg:"#8a96a2",fs:34,h:.55,border:"rgba(0,0,0,0)"});st.set("READY","rgba(0,0,0,0)","#8a96a2");
  st.sp.position.set(t.x,F1Y+5.0,23.6);GR.F.add(st.sp);labels.push({sp:st.sp});
  tuoStat[t.n]=st;tuoBusy[t.n]=false;
  var scr=new THREE.Mesh(new THREE.BoxGeometry(1.3,.8,.06),new THREE.MeshBasicMaterial({color:0x3ddc97}));
  scr.position.set(t.x,F1Y+1.5,24.83);GR.F.add(scr);
  makeLabel(t.ref,.6,GR.F,V(t.x+1.7,F1Y+t.h+1.3,28.0),{fs:28,col:"--muted"});
});
var scanMat=new THREE.MeshStandardMaterial({color:0x2a3441,roughness:.5,metalness:.3});
[-1.1,1.1].forEach(function(dz){var post=new THREE.Mesh(new THREE.BoxGeometry(.22,2.6,.22),scanMat);post.position.set(SCX,T+1.2,TZ+dz);GR.F.add(post);});
var scanBar=new THREE.Mesh(new THREE.BoxGeometry(.3,.26,2.5),scanMat);scanBar.position.set(SCX,T+2.5,TZ);GR.F.add(scanBar);
var scanHead=new THREE.Mesh(new THREE.BoxGeometry(.5,.4,.5),new THREE.MeshBasicMaterial({color:0xe0342f}));scanHead.position.set(SCX,T+2.15,TZ);GR.F.add(scanHead);
var dlCard=makeCard("DataLogic Trigger",{bg:"#17233a",fg:"#ffffff",fs:44,h:.95,border:"rgba(255,255,255,.25)"});
dlCard.sp.position.set(SCX,T+3.8,TZ);dlCard.sp.scale.multiplyScalar(.7);GR.F.add(dlCard.sp);labels.push({sp:dlCard.sp});
var bcLab=makeCard("BARCODE",{bg:"rgba(0,0,0,0)",fg:"#8a96a2",fs:34,h:.6,border:"rgba(0,0,0,0)"});
bcLab.sp.position.set(SCX+4.5,T+4.4,TZ);bcLab.sp.scale.multiplyScalar(.7);GR.F.add(bcLab.sp);labels.push({sp:bcLab.sp});
var bcNum=makeCard("waiting for tyre",{bg:"#ffffff",fg:"#1c2228",fs:50,h:1.0});
bcNum.sp.position.set(SCX+4.5,T+3.4,TZ);bcNum.sp.scale.multiplyScalar(.6);GR.F.add(bcNum.sp);labels.push({sp:bcNum.sp});
var rjCard=makeCard("Rejected conveyor",{bg:"#ffffff",fg:"#1c2228",fs:34,h:.8});
rjCard.sp.scale.multiplyScalar(.7);GR.F.add(rjCard.sp);labels.push({sp:rjCard.sp});

/* merger conveyor label, rejected conveyor label (with leader lines) and workers */
(function(){
  function leader(x,y0,y1,z){
    var l=new THREE.Mesh(new THREE.BoxGeometry(.05,y1-y0,.05),new THREE.MeshBasicMaterial({color:0x5a656f}));
    l.position.set(x,(y0+y1)/2,z);GR.F.add(l);
  }
  rjCard.sp.position.set(-19.5,T+2.0,38.0);leader(-19.5,T+.3,T+1.65,38.0);
  var mc=makeCard("Merger conveyor",{bg:"#ffffff",fg:"#1c2228",fs:34,h:.8});mc.sp.scale.multiplyScalar(.7);
  mc.sp.position.set(-11,T+2.0,40.2);GR.F.add(mc.sp);labels.push({sp:mc.sp});leader(-11,T+.3,T+1.65,40.2);
  var cb=new THREE.Mesh(new THREE.BoxGeometry(.7,1.5,.5),new THREE.MeshStandardMaterial({color:0xf4f7fa,roughness:.5}));
  cb.position.set(-9.6,F1Y+.75,41.6);GR.F.add(cb);
  function worker(x,z){
    var m=new THREE.MeshStandardMaterial({color:0xf4c20d}),sk=new THREE.MeshStandardMaterial({color:0xd9a77a});
    var b=new THREE.Mesh(new THREE.CylinderGeometry(.28,.34,1.1,12),m);b.position.set(x,F1Y+.55,z);GR.F.add(b);
    var h=new THREE.Mesh(new THREE.SphereGeometry(.24,12,10),sk);h.position.set(x,F1Y+1.35,z);GR.F.add(h);
  }
  worker(-17.9,38.2);worker(-12.6,40.8);worker(-4.5,31.0);worker(4.2,31.0);worker(-17.5,34.8);worker(-23.0+1,28.2);
})();
/* barcode reader on the FIS belt, before the first station */
(function(){
  var bx=FX-5.0;
  [-1.6,1.6].forEach(function(dz){var po=new THREE.Mesh(new THREE.BoxGeometry(.2,2.0,.2),scanMat);po.position.set(bx,A+1.0,FZ+dz);GR.G.add(po);});
  var br=new THREE.Mesh(new THREE.BoxGeometry(.26,.24,3.4),scanMat);br.position.set(bx,A+2.1,FZ);GR.G.add(br);
  var bh=new THREE.Mesh(new THREE.BoxGeometry(.4,.36,.4),new THREE.MeshBasicMaterial({color:0xe0342f}));bh.position.set(bx,A+1.75,FZ);GR.G.add(bh);
  var bc=makeCard("Barcode reader",{bg:"#17233a",fg:"#ffffff",fs:44,h:.95,border:"rgba(255,255,255,.25)"});
  bc.sp.position.set(bx,A+3.5,FZ);bc.sp.scale.multiplyScalar(.7);GR.G.add(bc.sp);labels.push({sp:bc.sp});
})();
/* FIS stations on the sorting level */
[1,3].forEach(function(f){makeLabel("FIS-"+f,1.0,GR.G,V(FX+CX[f],A+1.8,FZ),{fs:34});});
/* belt name labels */
var BL=[
  ["DBM drop",V(DROPX+2.0,B+1.3,BZ+2.2)],
  ["TRT belt",V(TRTX-2.3,B+1.2,17+DZ)],["FIS belt",V(FX-9,A+1.2,FZ-1.6)]
];
BL.forEach(function(b){makeLabel(b[0],.85,GR.G,b[1],{fs:30,col:"--muted"});});
(function(){   /* bypass label where the bypass tyres join at the far end of the TRT belt */
  var bp=makeCard("Bypass",{bg:"#ffffff",fg:"#1c2228",fs:34,h:.8,border:"rgba(0,0,0,.25)"});
  bp.sp.scale.multiplyScalar(.7);bp.sp.position.set(TRTX,B+1.7,OUTZ-0.4);GR.G.add(bp.sp);labels.push({sp:bp.sp});
})();
[["Zone 1 trunk 100",V(-10,T+1.2,TZ+1.8)]].forEach(function(b){makeLabel(b[0],.85,GR.F,b[1],{fs:30,col:"--muted"});});

/* sensors */
var sensEls=[];
function sensorMesh(s,isRefl){
  var c=C[s.c],y=nearestY(c.pts,s.x,s.z);
  var off=isRefl?1.0:-1.0,ox=s.ax==="z"?off:0,oz=s.ax==="x"?off:0;
  var m=new THREE.Mesh(new THREE.BoxGeometry(.42,.42,.42),new THREE.MeshStandardMaterial({color:0x8c97a1}));
  m.position.set(s.x+ox,y+.38,s.z+oz);GR[fkeyAtY(y)].add(m);
  return {m:m,y:y};
}
SENS.forEach(function(s){
  var r=sensorMesh(s,false);
  s.mesh=r.m;s.y=r.y;
  onTheme(function(){s.mesh.material.color.set(s.hit?css("--son"):css("--soff"));});
  makeLabel(s.id,.7,GR[fkeyAtY(r.y)],V(s.mesh.position.x,r.y+1.3,s.mesh.position.z),{fs:30,col:"--muted"});
  if(s.refl){
    var q=sensorMesh(s,true);
    q.m.scale.set(.8,.8,.8);
    onTheme(function(){q.m.material.color.set(css("--muted"));});
    makeLabel(s.refl,.6,GR[fkeyAtY(q.y)],V(q.m.position.x,q.y+1.1,q.m.position.z),{fs:28,col:"--muted"});
  }
});
REFL.forEach(function(s){
  var r=sensorMesh(s,true);r.m.scale.set(.8,.8,.8);
  onTheme(function(){r.m.material.color.set(css("--muted"));});
  makeLabel(s.id,.6,GR.G,V(r.m.position.x,r.y+1.1,r.m.position.z),{fs:28,col:"--muted"});
});

/* ---------- Zone 3, laid out as in the Zone 3 picture ----------
   Turned 90 degrees clockwise and placed beyond the far end of the DBM drop belt, so the 575BF3 roller block meets the drop beside S5.
   Rollers, green belt, sensor dots with their tags and the QA INSP buttons are all taken from the picture (1 px = 2.2 cm). */
/* picture u runs along +x, picture v along +z; 575BF3 block (u 588, v 25) sits on the line of the DBM drop */
function z3x(u){return Z3.xc+(u-588)*Z3.s;}
function z3z(v){return Z3.zn+(v-25)*Z3.s;}
var z3Frame=new THREE.MeshStandardMaterial({color:0x7a8592,roughness:.5,metalness:.5});
var z3Rol=new THREE.MeshStandardMaterial({color:0xd3d9e0,roughness:.3,metalness:.6});
var z3Dark=new THREE.MeshStandardMaterial({color:0x2b3440,roughness:.6,metalness:.2});
var z3GreenMat=new THREE.MeshStandardMaterial({color:0x12d02a,roughness:.6,metalness:.05});
function z3Box(cx,cy,cz,w,h,d,mat){var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(cx,cy,cz);GR.G.add(m);return m;}
function z3Rect(u1,v1,u2,v2){
  var xa=z3x(u1),xb=z3x(u2),za=z3z(v1),zb=z3z(v2);
  return {cx:(xa+xb)/2,cz:(za+zb)/2,w:Math.abs(xa-xb),d:Math.abs(za-zb)};
}
/* Zone 3 roller conveyors use the Zone 1 belt design (side rails, instanced rollers); the green belts keep their original look from the Zone 3 picture */
function z3Group(r){
  var horiz=r.w>r.d,g=new THREE.Group();
  g.position.set(r.cx,Z3.y,r.cz);g.quaternion.setFromUnitVectors(X,horiz?V(1,0,0):V(0,0,1));GR.G.add(g);
  return{g:g,len:horiz?r.w:r.d,wid:horiz?r.d:r.w,horiz:horiz};
}
function z3Legs(r,o){
  var n=Math.max(1,Math.floor(o.len/4));
  for(var q=1;q<=n;q++){
    var t=q/(n+1)-0.5;
    z3Box(o.horiz?r.cx+t*o.len:r.cx,Z3.y/2,o.horiz?r.cz:r.cz+t*o.len,.12,Z3.y,.12,railMat);
  }
}
function z3Roller(u1,v1,u2,v2,green){
  var r=z3Rect(u1,v1,u2,v2),o=z3Group(r),len=o.len,wid=o.wid;
  [-1,1].forEach(function(k){
    var rail=new THREE.Mesh(new THREE.BoxGeometry(len+0.02,0.26,0.07),frameBase);
    rail.position.set(0,0,k*(wid/2+0.035));o.g.add(rail);
  });
  var rn=Math.max(1,Math.floor(len/0.3)),im=new THREE.InstancedMesh(rollGeo,rollMat,rn),mt=new THREE.Matrix4(),qq=new THREE.Quaternion();
  for(var j=0;j<rn;j++){
    mt.compose(new THREE.Vector3((j+.5)*len/rn-len/2,0.03,0),qq,new THREE.Vector3(1,1,wid*0.95));
    im.setMatrixAt(j,mt);
  }
  o.g.add(im);
  if(green){var gp=greenTopPlane(len,wid-0.12,Math.max(1,Math.round(len/(wid*1.5))));gp.position.y=.12;o.g.add(gp);}   /* green belt with crossed cells, as in the Zone 3 picture */
  z3Legs(r,o);
}
function z3LegsOld(r){
  var horiz=r.w>r.d,len=horiz?r.w:r.d,n=Math.max(2,Math.round(len/4)+1);
  for(var i=0;i<n;i++){
    var t=n>1?i/(n-1)-0.5:0;
    [-1,1].forEach(function(k){
      var lx=horiz?r.cx+t*(r.w-0.3):r.cx+k*(r.w/2-0.05),lz=horiz?r.cz+k*(r.d/2-0.05):r.cz+t*(r.d-0.3);
      z3Box(lx,(Z3.y-0.1)/2,lz,0.08,Z3.y-0.1,0.08,z3Frame);
    });
  }
}
function z3Green(u1,v1,u2,v2,cells){
  var r=z3Rect(u1,v1,u2,v2),y=Z3.y;
  z3Box(r.cx,y-0.04,r.cz,r.w,0.12,r.d,z3GreenMat);
  [-1,1].forEach(function(k){z3Box(r.cx,y+0.04,r.cz+k*(r.d/2-0.03),r.w,0.2,0.06,z3Dark);});
  if(cells){   /* crossed cells, as drawn on the picture */
    var cv=document.createElement("canvas"),cw=100,ch=68;cv.width=cw*cells;cv.height=ch;
    var cx=cv.getContext("2d");cx.fillStyle="#12d02a";cx.fillRect(0,0,cv.width,ch);
    cx.strokeStyle="#0a7d17";cx.lineWidth=3;
    for(var i=0;i<cells;i++){
      cx.strokeRect(i*cw+1.5,1.5,cw-3,ch-3);
      cx.beginPath();cx.moveTo(i*cw,0);cx.lineTo((i+1)*cw,ch);cx.moveTo((i+1)*cw,0);cx.lineTo(i*cw,ch);cx.stroke();
    }
    var pl=new THREE.Mesh(new THREE.PlaneGeometry(r.w,r.d-0.12),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(cv)}));
    pl.rotation.x=-Math.PI/2;pl.position.set(r.cx,y+0.03,r.cz);GR.G.add(pl);
  }
  z3LegsOld(r);
}
function z3Dot(u,v,orange){
  var x=z3x(u),z=z3z(v),y=(u>=540?B:Z3.y)+0.55;
  z3Box(x,y/2,z,0.04,y,0.04,z3Frame);
  var m=new THREE.Mesh(new THREE.SphereGeometry(0.15,14,10),new THREE.MeshStandardMaterial(orange?{color:0xff7a1a,emissive:0x5a2400,roughness:.4}:{color:0x66d68a,emissive:0x12401f,roughness:.4}));
  m.position.set(x,y,z);GR.G.add(m);
}
function z3Tag(text,u,v,col,dy){makeLabel(text,.6,GR.G,V(z3x(u),(u>=540?B:Z3.y)+(dy||1.1),z3z(v)),{fs:28,col:col||"--ink"});}
/* conveyors */
z3Roller(67,73,118,320);          /* left vertical roller conveyor */
Z3.y=B;z3Roller(563,25,613,126);Z3.y=A;   /* small roller block at the drop, stays at 1.35 m */
z3Roller(116,275,915,325);        /* long roller conveyor, bottom */
z3Box(z3x(915),Z3.y+0.1,z3z(300),0.1,0.34,z3Rect(0,275,0,325).d,z3GreenMat);   /* green end stop */
/* sensor dots and tags */
[[53,98,0],[95,132,1],[53,150,0],[53,200,1],[53,250,1],[53,295,0],[97,333,0],[549,64,1],[549,117,1],[921,299,0]].forEach(function(d){z3Dot(d[0],d[1],d[2]);});
var z3Row=["5123","5174","5175","6523","6524","6525","6526","6527","6528"],z3RowU=[142,227,312,398,484,569,655,741,826],z3RowOr=[0,1,1,0,0,1,1,0,0];
z3Row.forEach(function(t,i){z3Dot(z3RowU[i],262,z3RowOr[i]);z3Tag(t,z3RowU[i]+38,250,"--ink",1.2);});
[["512M7",98],["512S",142],["512S1",182],["522S1",230],["522S2",282]].forEach(function(t){z3Tag(t[0],20,t[1],"#2f5bd9",1.0);});
z3Tag("5123",132,57,"--ink",1.0);z3Tag("575BF3",645,47,"--ink",1.0);z3Tag("575BF4",645,101,"--ink",1.0);
/* QA INSP buttons */
[["QA INSP-1 IO",281,368,"#334155","#ffffff"],["QA INSP-2 IO",459,368,"#334155","#ffffff"],["QA INSP-3 IO",644,368,"#334155","#ffffff"],
 ["QA INSP-1O  ·  Enable",302,409,"#334155","#ffffff"],["QA INSP-283  ·  Enable",667,409,"#0fd22a","#06260b"]].forEach(function(b){
  var cd=makeCard(b[0],{bg:b[3],fg:b[4],fs:40,h:.62,border:"rgba(255,255,255,.25)"});
  cd.sp.position.set(z3x(b[1]),0.55,z3z(b[2]));GR.G.add(cd.sp);labels.push({sp:cd.sp});
});
makeLabel("ZONE 3",1.0,GR.G,V(z3x(480),Z3.y+3.0,z3z(10)),{col:"--fs",fs:34});
/* barcode scanner over the Zone 3 entry roller, between the 512S1 and 522S1 sensor tags */
(function(){
  var bx=z3x(92.5),bz=z3z(220),y0=Z3.y;
  [-1.1,1.1].forEach(function(dx){var po=new THREE.Mesh(new THREE.BoxGeometry(.2,2.2,.2),scanMat);po.position.set(bx+dx,y0+1.1,bz);GR.G.add(po);});
  var br=new THREE.Mesh(new THREE.BoxGeometry(2.5,.26,.3),scanMat);br.position.set(bx,y0+2.1,bz);GR.G.add(br);
  var bh=new THREE.Mesh(new THREE.BoxGeometry(.4,.36,.4),new THREE.MeshBasicMaterial({color:0xe0342f}));bh.position.set(bx,y0+1.7,bz);GR.G.add(bh);
  var bc=makeCard("Barcode scanner",{bg:"#17233a",fg:"#ffffff",fs:44,h:.95,border:"rgba(255,255,255,.25)"});
  bc.sp.position.set(bx,y0+3.3,bz);bc.sp.scale.multiplyScalar(.7);GR.G.add(bc.sp);labels.push({sp:bc.sp});
})();
/* FIS-1, FIS-2 and FIS-3 drop-out stations along the long Zone 3 roller: a diverter plate on the roller and a short drop-out conveyor to the side, with a callout label */
(function(){
  var zc=z3z(300),y0=Z3.y;
  var blue=new THREE.MeshStandardMaterial({color:0x1f4f9a,roughness:.5,metalness:.3}),
      plate=new THREE.MeshStandardMaterial({color:0x23282e,roughness:.6,metalness:.2}),
      metal=new THREE.MeshStandardMaterial({color:0xaab4be,roughness:.35,metalness:.7}),
      black=new THREE.MeshStandardMaterial({color:0x15181c,roughness:.8});
  [[1,305,1],[2,770,-1],[3,822,1]].forEach(function(d){
    var x=z3x(d[1]),sd=d[2];
    /* diverter plate: runs diagonally across the roller so a tyre is pushed off to side sd */
    var pl=z3Box(x,y0+.42,zc,2.0,.5,.05,plate);pl.rotation.y=-sd*Math.PI/4;
    /* blue frame post and pneumatic cylinder on the far side of the roller */
    z3Box(x-.1,y0+.35,zc-sd*1.0,.12,.9,.12,blue);
    var cy=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,.9,10),metal);cy.rotation.x=Math.PI/2;cy.position.set(x-.1,y0+.6,zc-sd*.62);GR.G.add(cy);
    /* drop-out conveyor leaving the roller on side sd */
    var cx=x+.7,cz=zc+sd*(.76+1.2),by=y0-.1;
    z3Box(cx,by,cz,1.0,.08,2.4,black);
    [-1,1].forEach(function(k){
      z3Box(cx+k*.55,by+.12,cz,.07,.22,2.4,blue);
      z3Box(cx+k*.5,(by-.04)/2,zc+sd*(.76+2.2),.1,by-.04,.1,blue);
    });
    /* callout label with leader line and dot, as in the reference photo */
    var ly=y0+2.3;
    z3Box(x,(y0+.7+ly)/2,zc,.03,ly-(y0+.7),.03,metal);
    var dot=new THREE.Mesh(new THREE.SphereGeometry(.09,12,10),new THREE.MeshBasicMaterial({color:0x2d63b0}));dot.position.set(x,y0+.7,zc);GR.G.add(dot);
    var cd=makeCard("FIS-"+d[0],{bg:"#17294d",fg:"#ffffff",fs:44,h:.95,border:"rgba(255,255,255,.35)"});
    cd.sp.position.set(x,ly+.3,zc);cd.sp.scale.multiplyScalar(.7);GR.G.add(cd.sp);labels.push({sp:cd.sp});
  });
})();

/* anti-collision photo-eyes: one about every 4 m on every belt, with a reflector on the opposite rail.
   A tyre may not enter the zone of an eye that an older tyre ahead of it is blocking. */
var GUARDS=[];
(function(){
  var gS=new THREE.BoxGeometry(.3,.3,.3),gR=new THREE.BoxGeometry(.22,.22,.22);
  ORDER.forEach(function(id){
    var c=C[id];
    if(c.nobuild||id==="br08")return;
    var path={pts:c.pts,cum:cumOf(c.pts)},Lt=path.cum[path.cum.length-1];
    var n=Math.max(1,Math.floor(Lt/4));
    for(var i=0;i<n;i++){
      var pa=posAt(path,(i+.5)*Lt/n),p=pa.p,h=pa.h;
      if(id==="z1trunk"&&p.z<TZ-0.01)continue;
      if(id==="rejz"&&p.x>RJZ-1.55&&p.z<36.55)continue;
      var sx=-h.z,sz=h.x,sl=Math.hypot(sx,sz);if(sl<1e-3)continue;sx/=sl;sz/=sl;
      if(REMOVED[id]){GUARDS.push({c:id,p:p.clone(),m:null,occ:[],hit:false});continue;}
      var off=c.w/2+0.5,y=p.y+.38,fk=fkeyAtY(p.y);
      var m=new THREE.Mesh(gS,new THREE.MeshStandardMaterial({color:0x8c97a1}));
      m.position.set(p.x+sx*off,y,p.z+sz*off);
      var q=new THREE.Mesh(gR,new THREE.MeshStandardMaterial({color:0x8c97a1}));
      q.position.set(p.x-sx*off,y,p.z-sz*off);
      GR[fk].add(m);GR[fk].add(q);
      var g={c:id,p:p.clone(),m:m,occ:[],hit:false};
      (function(g,q){onTheme(function(){g.m.material.color.set(g.hit?css("--son"):css("--soff"));q.material.color.set(css("--muted"));});})(g,q);
      GUARDS.push(g);
    }
  });
})();
/* where each eye sits along a tyre's route (distance travelled), found once per tyre */
function guardMap(path){
  var o=[],ids={};
  path.marks.forEach(function(m){ids[m.id]=1;});
  GUARDS.forEach(function(g){
    if(!ids[g.c])return;
    var best=1e9,bd=0;
    for(var j=0;j<path.pts.length-1;j++){
      var a=path.pts[j],b=path.pts[j+1],dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,L2=dx*dx+dy*dy+dz*dz;
      var t=L2?((g.p.x-a.x)*dx+(g.p.y-a.y)*dy+(g.p.z-a.z)*dz)/L2:0;t=Math.max(0,Math.min(1,t));
      var ex=a.x+dx*t-g.p.x,ey=a.y+dy*t-g.p.y,ez=a.z+dz*t-g.p.z,dd=ex*ex+ey*ey+ez*ez;
      if(dd<best){best=dd;bd=path.cum[j]+t*Math.sqrt(L2);}
    }
    if(best<0.64)o.push({g:g,d:bd});
  });
  return o;
}

/* tyres */
var tyreGeo=new THREE.TorusGeometry(.4,.15,10,26);
var tyreMats={};
[1,2,3].forEach(function(f){
  tyreMats[f]=new THREE.MeshStandardMaterial({color:0x0b0b0b,roughness:.6,metalness:.05});
});

/* ---------- simulation ---------- */
var running=true,speed=1,rate=30,dbmShare=70,z3Share=30;
var tyres=[],nextId=1,simT=0,spawnAcc=0,done=[];
var rec={1:0,2:0,3:0},nDbm=0,nByp=0,nRej=0,nZ3={1:0,2:0,3:0};
var BELT_V=2.4;

function spawn(){
  var lane=Math.random()<.5?"A":"B";
  var r=Math.random(),dest=r<.55?1:3;
  var via=Math.random()*100<dbmShare?(Math.random()<.5?"dbm1":"dbm2"):"bypass";
  var k=1+Math.floor(Math.random()*5);
  var noRead=Math.random()<.05;
  var z3n=(!noRead&&Math.random()*100<z3Share)?1+Math.floor(Math.random()*3):0;   /* tyres sent on to Zone 3 along the FIS belt */
  var path=z3n?routeZ3(via,dest,z3n):route(k,lane,via,dest,noRead);
  if(z3n)k=0;
  var start=path.pts[0];
  for(var i=0;i<tyres.length;i++){if(tyres[i].d<2.2&&tyres[i].p.p.distanceTo(start)<1.6)return;}
  var sx=LANE[lane],holdD=null;
  /* lane hold-and-release not used with reversed flow */
  var t={id:nextId++,k:k,z3:z3n,lane:lane,via:via,dest:dest,noRead:noRead,path:path,d:0,mi:0,blocked:false,released:false,holdD:holdD,
         wait:1.8+Math.random()*1.6,code:"10558"+("00000"+Math.floor(Math.random()*100000)).slice(-5),
         p:posAt(path,0),mesh:null,gd:guardMap(path),gh:false,by:0,byPrev:0};
  C[path.marks[0].id].passed++;
  var mm=new THREE.Mesh(tyreGeo,tyreMats[dest]);
  mm.rotation.x=Math.PI/2;
  scene.add(mm);t.mesh=mm;
  tyres.push(t);
}
var tyreById={};
function waitsFor(b,a){   /* is b (through a chain of tyres each waiting for the next) waiting for a? */
  var c=b,n=0;
  while(c&&n<10){var id=c.byPrev;if(!id)return false;if(id===a.id)return true;c=tyreById[id];n++;}
  return false;
}
function blocksTyre(b,a,dist){   /* a tyre directly in front stops the one behind; if two end up waiting for each other, the older goes first */
  var dv=b.p.p.clone().sub(a.p.p);
  if(dv.dot(a.p.h)<=0)return false;
  if(waitsFor(b,a)&&a.id<b.id)return false;
  return true;
}
function yieldsAtCrossing(a,b){   /* two tyres on crossing or merging belts: the one that is farther from the crossing point waits */
  var ha=a.p.h,hb=b.p.h,det=ha.x*hb.z-ha.z*hb.x;
  if(Math.abs(det)<0.25||Math.abs(b.p.p.y-a.p.p.y)>1.0)return false;
  var rx=b.p.p.x-a.p.p.x,rz=b.p.p.z-a.p.p.z;
  var sa=(rx*hb.z-rz*hb.x)/det,sb=(ha.z*rx-ha.x*rz)/det;   /* distances still to travel to the crossing point */
  if(sa<-0.7||sb<-0.7||sa>7||sb>7||Math.abs(sa-sb)>1.5)return false;
  return sa>sb+0.05||(Math.abs(sa-sb)<=0.05&&a.id>b.id);
}
function bandBusy(sx,self){
  for(var i=0;i<tyres.length;i++){
    var o=tyres[i];if(o===self)continue;
    var p=o.p.p;
    if(Math.abs(p.y-A)<.5&&Math.abs(p.z-BZ)<.9&&p.x>sx-1.6&&p.x<sx+7)return true;
  }
  return false;
}
function removeTyre(i){
  var t=tyres[i];scene.remove(t.mesh);tyres.splice(i,1);
}
function step(dt){
  simT+=dt;spawnAcc+=dt;
  var iv=60/rate,i,j;
  while(spawnAcc>=iv){spawnAcc-=iv;spawn();}
  for(i=0;i<tyres.length;i++)tyres[i].p=posAt(tyres[i].path,tyres[i].d);
  tyreById={};
  for(i=0;i<tyres.length;i++){tyres[i].byPrev=tyres[i].by;tyres[i].by=0;tyreById[tyres[i].id]=tyres[i];}
  for(i=0;i<GUARDS.length;i++){
    var gg=GUARDS[i];gg.occ.length=0;
    for(j=0;j<tyres.length;j++){
      var gq=tyres[j].p.p;
      if(Math.abs(gq.y-gg.p.y)<1.0&&Math.hypot(gq.x-gg.p.x,gq.z-gg.p.z)<.8)gg.occ.push(tyres[j]);
    }
  }
  for(i=0;i<tyres.length;i++){
    var a=tyres[i];a.blocked=false;a.gh=false;
    if(a.holdD!==null&&!a.released&&a.d>=a.holdD){
      if(bandBusy(LANE[a.lane],a))a.blocked=true;else a.released=true;
    }
    if(a.blocked)continue;
    for(var gk=0;gk<a.gd.length&&!a.blocked;gk++){
      var gdd=a.gd[gk].d-a.d;
      if(gdd>0.05&&gdd<1.7){
        var oc=a.gd[gk].g.occ;
        for(var ok=0;ok<oc.length;ok++){
          var ob=oc[ok];
          if(ob!==a&&blocksTyre(ob,a,ob.p.p.distanceTo(a.p.p))){a.blocked=true;a.gh=true;a.by=ob.id;break;}
        }
      }
    }
    if(a.blocked)continue;
    for(j=0;j<tyres.length;j++){
      var b=tyres[j];if(b===a)continue;
      var dist=b.p.p.distanceTo(a.p.p);
      if(a.p.h.dot(b.p.h)>0.5){
        if(dist<1.35&&blocksTyre(b,a,dist)){a.blocked=true;a.by=b.id;break;}
      }else{   /* crossing or merging belts: the younger tyre stops early if the two would meet, otherwise they pass */
        if(dist<1.15&&blocksTyre(b,a,dist)){a.blocked=true;a.by=b.id;break;}
        if(dist<8&&yieldsAtCrossing(a,b)&&!(waitsFor(b,a)&&a.id<b.id)){a.blocked=true;a.by=b.id;break;}
      }
    }
  }
  for(i=tyres.length-1;i>=0;i--){
    var t=tyres[i],v=BELT_V;
    if(t.wait>0){t.wait-=dt;}else if(!t.blocked)t.d+=v*dt;
    if(t.holdD!==null&&!t.released&&t.d>t.holdD){t.d=t.holdD;}
    while(t.mi+1<t.path.marks.length&&t.d>=t.path.marks[t.mi+1].d){t.mi++;C[t.path.marks[t.mi].id].passed++;if(C[t.path.marks[t.mi].id].nobuild&&t.mi+1<t.path.marks.length)t.d=t.path.marks[t.mi+1].d;}
    if(t.d>=t.path.total){
      t.d=t.path.total;t.blocked=true;
      if(t.dwell===undefined)t.dwell=2.2+Math.random()*1.6;
      t.dwell-=dt;
      if(t.dwell<=0){
        if(t.noRead)nRej++;
        else if(t.z3){nZ3[t.z3]++;}
        else{rec[t.dest]++;if(t.via==="bypass")nByp++;else nDbm++;}
        done.push(simT);removeTyre(i);
      }
    }
  }
  while(done.length&&done[0]<simT-60)done.shift();
}
function resetSim(){
  while(tyres.length)removeTyre(tyres.length-1);
  nextId=1;simT=0;spawnAcc=0;done=[];rec={1:0,2:0,3:0};nDbm=0;nByp=0;nRej=0;nZ3={1:0,2:0,3:0};
  ORDER.forEach(function(k){C[k].passed=0;C[k].now=0;});
  for(var i=0;i<500;i++)step(.1);
}

/* ---------- per-frame ---------- */
function updateZ1(){
  TUO.forEach(function(t){
    var busy=false;
    for(var i=0;i<tyres.length;i++){var y=tyres[i];if(y.k===t.n&&y.d>=y.path.total-1.2){busy=true;break;}}
    if(busy!==tuoBusy[t.n]){tuoBusy[t.n]=busy;tuoStat[t.n].set(busy?"TESTING":"READY","rgba(0,0,0,0)",busy?"#c27e0e":"#8a96a2");}
  });
  for(var j=0;j<tyres.length;j++){
    var q=tyres[j].p.p;
    if(Math.abs(q.y-T)<.6&&Math.hypot(q.x-SCX,q.z-TZ)<.6){
      if(tyres[j].id!==lastBC){
        lastBC=tyres[j].id;
        if(tyres[j].noRead)bcNum.set("NO READ","#cf3535","#ffffff");else bcNum.set(tyres[j].code,"#ffffff","#1c2228");
      }
      break;
    }
  }
}
function frame(dt){
  for(var i=0;i<tyres.length;i++){
    var t=tyres[i];t.p=posAt(t.path,t.d);
    var p=t.p.p;
    t.mesh.position.set(p.x,p.y+.27,p.z);
    t.mesh.visible=on[fkeyAtY(p.y)]&&!((Math.abs(p.x-LANE.A)<.6||Math.abs(p.x-LANE.B)<.6)&&p.z>ZL+0.1&&p.z<TZ-0.01)&&!REMOVED[t.path.marks[t.mi].id];   /* no tyres on removed belts */
  }
  GUARDS.forEach(function(g){
    var hit=g.occ.length>0;
    if(hit!==g.hit){g.hit=hit;if(g.m)g.m.material.color.set(hit?css("--son"):css("--soff"));}
  });
  SENS.forEach(function(s){
    var hit=false;
    for(var k=0;k<tyres.length;k++){
      var p=tyres[k].p.p;
      if(Math.abs(p.y-s.y)<1.0&&Math.hypot(p.x-s.x,p.z-s.z)<.8){hit=true;break;}
    }
    if(hit!==!!s.hit){
      s.hit=hit;s.mesh.material.color.set(hit?css("--son"):css("--soff"));
      var ch=$("sc"+s.id);if(ch)ch.className="sc"+(hit?" hit":"");
    }
  });
  updateZ1();
  if(running){var o=dt*speed*BELT_V/1.6;texes.forEach(function(t){t.offset.x-=o;});}
}
function stats(){
  var i,j;
  ORDER.forEach(function(k){C[k].now=0;});
  var pf={G:0,F:0};
  for(i=0;i<tyres.length;i++){
    var t=tyres[i],m=t.path.marks,cur=m[0].id;
    for(j=0;j<m.length;j++){if(t.d>=m[j].d)cur=m[j].id;}
    C[cur].now++;pf[fkeyAtY(t.p.p.y)]++;
  }
  $("kIn").textContent=tyres.length;
  var cgOn=0,cgHeld=0;
  GUARDS.forEach(function(g){if(g.occ.length)cgOn++;});
  tyres.forEach(function(t){if(t.gh)cgHeld++;});
  $("cgInfo").textContent="Anti-collision eyes: "+GUARDS.length+" on all belts, "+cgOn+" tripped, "+cgHeld+" tyres held back";
  $("kRec").textContent=rec[1]+rec[3]+nZ3[1]+nZ3[2]+nZ3[3];
  $("kDbm").textContent=nDbm;$("kByp").textContent=nByp;
  var span=Math.min(60,Math.max(simT,1));
  $("kTp").textContent=Math.round(done.length*60/span);
  var rows=$("floorRows");
  if(!rows.children.length){
    rows.innerHTML=[1,3].map(function(n){
      var col=["--f1","--f2","--f3"][n-1];
      return '<tr><td><div class="fl"><i style="background:var('+col+')"></i><div>FIS-'+n+'<small>incline to '+TBN[n]+'</small></div></div></td><td class="n" id="ft'+n+'"></td><td class="n" id="fd'+n+'"></td></tr>';
    }).join("")+'<tr><td><div class="fl"><i style="background:var(--son)"></i><div>Zone 1 reject<small>rejected conveyor, no-read tyres</small></div></div></td><td class="n" id="ftR"></td><td class="n" id="fdR"></td></tr><tr><td><div class="fl"><i style="background:var(--fz)"></i><div>Zone 3<small>FIS-1, FIS-2, FIS-3 on the long roller</small></div></div></td><td class="n" id="ftZ"></td><td class="n" id="fdZ"></td></tr>';
  }
  [1,3].forEach(function(n){
    $("ft"+n).textContent=C["inc"+n].now+C["tab"+n].now;
    $("fd"+n).textContent=rec[n];
  });
  $("ftZ").textContent=C.z3link.now+C.z3path.now;$("fdZ").textContent=nZ3[1]+nZ3[2]+nZ3[3];
  $("ftR").textContent=C.rejz.now+C.rejstub.now;$("fdR").textContent=nRej;
  var zr=$("zoneRows");
  if(!zr.children.length){
    zr.innerHTML=FLOORS.slice().reverse().map(function(f){
      return '<tr><td><div class="fl"><i style="background:var('+f.col+')"></i><div>'+f.name+'<small>'+f.role+'</small></div></div></td><td class="n" id="zt'+f.k+'"></td><td class="n" id="zb'+f.k+'"></td></tr>';
    }).join("");
  }
  FLOORS.forEach(function(f){
    $("zt"+f.k).textContent=pf[f.k];
    var n=0;ORDER.forEach(function(id){if(C[id].grp===f.k&&!C[id].nobuild&&!REMOVED[id])n++;});
    $("zb"+f.k).textContent=n;
  });
  if(sel){var a=$("dNow"),b=$("dPass");if(a)a.textContent=C[sel].now;if(b)b.textContent=C[sel].passed;}
}

/* ---------- selection ---------- */
var sel=null,ray=new THREE.Raycaster(),pm=new THREE.Vector2(),downAt=null;
function select(id){
  if(sel)C[sel].bodyMats.forEach(function(m){if(m.emissive)m.emissive.set(0x000000);});
  sel=id;
  if(sel)C[sel].bodyMats.forEach(function(m){if(m.emissive)m.emissive.set(css("--accent")).multiplyScalar(.55);});
  var box=$("detail");
  if(!sel){box.innerHTML='<p class="hint">Click any belt in the 3D view to see its drawing numbers, height and flow.</p>';return;}
  var c=C[sel];
  box.innerHTML='<dl><dt>Name</dt><dd>'+c.name+'</dd><dt>Drawing no.</dt><dd>'+c.ref+'</dd><dt>Level</dt><dd>'+(c.grp==="F"?"First floor, Zone 1":"Ground floor, Zone 2")+'</dd><dt>Height</dt><dd>'+c.h+'</dd><dt>Flow</dt><dd style="font-family:var(--font-body)">'+c.flow+'</dd><dt>On belt</dt><dd id="dNow">'+c.now+'</dd><dt>Passed</dt><dd id="dPass">'+c.passed+'</dd></dl>';
}
canvas.addEventListener("pointerdown",function(e){downAt=[e.clientX,e.clientY];});
canvas.addEventListener("pointerup",function(e){
  if(!downAt||Math.abs(e.clientX-downAt[0])+Math.abs(e.clientY-downAt[1])>6)return;
  var r=canvas.getBoundingClientRect();
  pm.set(((e.clientX-r.left)/r.width)*2-1,-((e.clientY-r.top)/r.height)*2+1);
  ray.setFromCamera(pm,camera);
  var vis=pickables.filter(function(m){var c=C[m.userData.id];return !c.hidden&&on[c.grp];});
  var h=ray.intersectObjects(vis,false);
  select(h.length?h[0].object.userData.id:null);
});

/* ---------- camera ---------- */
var PRESET={
  over:{p:V(34,26,48),t:V(-1,3,3)},
  top:{p:V(1.5,86,1),t:V(1.5,0,0.5)},
  side:{p:V(76,10,1),t:V(1,3,1)},
  z1:{p:V(10,19,60),t:V(-5,4,31)},
  z1t:{p:V(-7,44,32.6),t:V(-7,0,32)},
  fis:{p:V(-38,13,36+DZ),t:V(-22,1.5,20+DZ)}
};
var tween=null;
function flyTo(k){tween={t:0,p0:camera.position.clone(),t0:controls.target.clone(),p1:PRESET[k].p,t1:PRESET[k].t};
  ["cOver","cTop","cSide","cFis","cZ1","cZ1T"].forEach(function(id){$(id).classList.remove("on");});
  $({over:"cOver",top:"cTop",side:"cSide",fis:"cFis",z1:"cZ1",z1t:"cZ1T"}[k]).classList.add("on");}
function snap(k){camera.position.copy(PRESET[k].p);controls.target.copy(PRESET[k].t);controls.update();}

/* ---------- controls ---------- */
var chipHost=$("floorChips");
FLOORS.slice().reverse().forEach(function(f){
  var lab=document.createElement("label");lab.className="chip checked";lab.style.setProperty("--c","var("+f.col+")");
  lab.innerHTML='<input type="checkbox" id="fc'+f.k+'" checked><i></i>'+f.name;
  chipHost.appendChild(lab);
  lab.querySelector("input").addEventListener("change",function(ev){
    on[f.k]=ev.target.checked;GR[f.k].visible=on[f.k];lab.classList.toggle("checked",on[f.k]);
  });
});
$("lbl").addEventListener("change",function(ev){
  labelsOn=ev.target.checked;this.parentNode.classList.toggle("checked",labelsOn);
  labels.forEach(function(l){l.sp.visible=labelsOn;});
});
var playB=$("play");
playB.addEventListener("click",function(){running=!running;playB.textContent=running?"Pause":"Play";playB.classList.toggle("on",running);});
$("reset").addEventListener("click",resetSim);
$("speed").addEventListener("change",function(e){speed=parseFloat(e.target.value);});
$("rate").addEventListener("input",function(e){rate=parseInt(e.target.value,10);$("rateV").textContent=rate+" /min";});
$("dbm").addEventListener("input",function(e){dbmShare=parseInt(e.target.value,10);$("dbmV").textContent=dbmShare+" %";});
$("z3r").addEventListener("input",function(e){z3Share=parseInt(e.target.value,10);$("z3rV").textContent=z3Share+" %";});
$("cOver").addEventListener("click",function(){flyTo("over");});
$("cTop").addEventListener("click",function(){flyTo("top");});
$("cSide").addEventListener("click",function(){flyTo("side");});
$("cFis").addEventListener("click",function(){flyTo("fis");});
$("cZ1").addEventListener("click",function(){flyTo("z1");});
$("cZ1T").addEventListener("click",function(){flyTo("z1t");});
$("sens").innerHTML=SENS.map(function(s){return '<div class="sc" id="sc'+s.id+'"><em></em><b>'+s.id+'</b><span>'+s.name+'</span></div>';}).join("");

function resize(){
  var w=stage.clientWidth,h=stage.clientHeight;
  if(!w||!h)return;
  renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();
}
if(window.ResizeObserver)new ResizeObserver(resize).observe(stage);else window.addEventListener("resize",resize);
if(window.matchMedia)try{window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",applyTheme);}catch(e){}
new MutationObserver(applyTheme).observe(document.documentElement,{attributes:true,attributeFilter:["data-theme"]});

/* ---------- boot ---------- */
applyTheme();resize();snap("over");resetSim();stats();
var last=performance.now(),statT=0;
function loop(now){
  var dt=Math.min(.05,(now-last)/1000);last=now;
  if(running)step(dt*speed);
  if(tween){tween.t=Math.min(1,tween.t+dt/.9);var e=tween.t<.5?2*tween.t*tween.t:1-Math.pow(-2*tween.t+2,2)/2;
    camera.position.lerpVectors(tween.p0,tween.p1,e);controls.target.lerpVectors(tween.t0,tween.t1,e);if(tween.t>=1)tween=null;}
  controls.update();
  frame(dt);
  statT+=dt;if(statT>.25){statT=0;stats();}
  renderer.render(scene,camera);
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
window.__twin={tyres:function(){return tyres.length;}};
})();
