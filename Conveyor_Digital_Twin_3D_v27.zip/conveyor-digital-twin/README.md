# Conveyor Digital Twin 3D

Live 3D simulation of the tyre conveyor layout (Zone 1, Zone 2, Zone 3).

## Run
Open `index.html` in a browser. Internet is needed once for three.js (jsDelivr CDN) and the Google fonts.
Optional local server: `python3 -m http.server 8000` then open http://localhost:8000

## Files
- `index.html`  page structure (control bar, 3D stage, readouts)
- `css/style.css`  layout and light/dark theme
- `js/app.js`  conveyor layout, tyre routes, simulation, 3D scene

## Controls
Drag = rotate, scroll = zoom, right-drag = pan, click a belt for details.
